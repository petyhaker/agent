# agent

Instructions: 
1. use swipl 
2. consult(agent). 
3. run "start(X)."

the output shows the path that the agent can cross on each of the stores. 
change the "graph" files (change the status codes as an indication that something went wrong) in the database folder to verify that the agent will stop on different nodes on each store. 
